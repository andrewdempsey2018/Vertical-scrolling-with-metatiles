.segment "ZEROPAGE"

.segment "CODE"
.export reset_handler
.proc reset_handler
  sei
  cld
  ldx #$40
  stx APU
  ldx #$FF
  txs
  inx
  stx PPUCTRL
  stx PPUMASK
  stx IRQ_ENABLE
  bit PPUSTATUS
vblankwait:
  bit PPUSTATUS
  bpl vblankwait

	ldx #$00
	lda #$FF
clear_oam:
	sta PPUCTRL, x ; set sprite y-positions off the screen
	inx
	inx
	inx
	inx
	bne clear_oam

  lda #$00
  sta scroll_y
  sta nametable_number
  sta row_address
  sta level_data
  sta row_number

vblankwait2:
  bit PPUSTATUS
  bpl vblankwait2
  jmp main
.endproc