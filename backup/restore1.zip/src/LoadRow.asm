.proc LoadRow
  php                   ; save registers
  pha
  txa
  pha
  tya
  pha

  ldy row_number

  lda RowLow, y
  sta row_address
  
  lda nametable_number
  eor #$02
  cmp #$00
  bne Nametable2
  lda RowHighNT0, y
  sta row_address+1
  jmp DrawRow
Nametable2:
  lda RowHighNT2, y
  sta row_address+1

DrawRow:
  lda PPUSTATUS
  lda row_address + 1
  sta PPUADDR
  lda row_address
  sta PPUADDR
  ldx #$20
  ldy #$00
DrawRowLoop:
  lda #2
  sta PPUDATA
  iny
  dex
  bne DrawRowLoop

  pla                   ; restore registers
  tay
  pla
  tax
  pla
  plp

  rts
.endproc